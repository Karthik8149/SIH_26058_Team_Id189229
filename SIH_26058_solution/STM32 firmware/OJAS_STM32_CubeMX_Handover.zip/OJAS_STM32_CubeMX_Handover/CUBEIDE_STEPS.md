# OJAS CubeIDE Bring-Up Order

1. Create/open a CubeIDE project for STM32H7A3ZIT6.
2. Load `OJAS_H7A3ZI.ioc` or reproduce the settings from `OJAS_PIN_UART_CONFIG.md` in CubeMX.
3. Generate code.
4. Copy the OJAS `Core/Inc` and `Core/Src` files from the STM32 firmware ZIP.
5. Integrate the OJAS application call into generated `main.c`.
6. Build and flash.
7. Test USART3 first: laptop should receive a simple OJAS boot banner.
8. Connect Arduino D1/TX through a level shifter to PB7/D0.
9. Confirm raw Arduino packets arrive at LPUART1.
10. Confirm STM32 Mackenzie result.
11. Confirm Wxx selection.
12. Confirm waveform metadata on laptop.
13. Only then enable DAC2 PA6 / DMA waveform output.
