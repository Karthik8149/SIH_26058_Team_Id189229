# OJAS – NUCLEO-H7A3ZI-Q Exact Pin / UART Configuration

## 1. Final architecture

Arduino UNO -> STM32 -> ST-LINK VCP -> Laptop

Arduino transmits environmental parameters:
- DEPTH_M
- TEMP_C
- SAL_PSU
- TURB_NTU
- sequence/profile metadata

STM32 performs:
1. Packet parsing
2. Mackenzie sound-speed calculation
3. W01–W24 sensor/Mackenzie LUT selection
4. Waveform-LUT lookup
5. Waveform generation
6. Laptop reporting / waveform streaming

## 2. Arduino -> STM32

Peripheral: LPUART1

| Function | STM32 pin | Nucleo Arduino header | Direction |
|---|---|---|---|
| LPUART1_TX | PB6 | D1 | STM32 -> Arduino (optional) |
| LPUART1_RX | PB7 | D0 | Arduino -> STM32 |
| GND | GND | GND | Common |

Configuration:
- Baud: 115200
- Data: 8 bits
- Parity: None
- Stop bits: 1
- Flow control: None
- Mode: Asynchronous

### Wiring

Arduino UNO TX (D1) -> 5 V to 3.3 V level shifter -> NUCLEO PB7 (D0)
Arduino GND -> NUCLEO GND

Do NOT connect a 5 V Arduino TX directly to the STM32 RX.

The first demo is one-way, so PB6/Arduino D1 on the STM32 side does not need to be connected back to Arduino unless command/control is enabled later.

## 3. STM32 -> Laptop

Peripheral: USART3

| Function | STM32 pin | Nucleo signal | Direction |
|---|---|---|---|
| USART3_TX | PD8 | ST-LINK VCP TX path | STM32 -> Laptop |
| USART3_RX | PD9 | ST-LINK VCP RX path | Laptop -> STM32 (optional) |

Configuration:
- Baud: 460800
- Data: 8 bits
- Parity: None
- Stop bits: 1
- Flow control: None
- Mode: Asynchronous

No external USB-UART converter is required for the laptop link. Use the Nucleo ST-LINK USB connection and select its Virtual COM Port on the PC.

## 4. Optional DAC output

Peripheral: DAC2 Channel 1

- Signal: DAC2_OUT1
- STM32 pin: PA6
- Nucleo connector: CN7 pin 12

Use only after the UART + LUT + laptop pipeline is working.

Recommended initial setting:
`OJAS_ENABLE_DAC = 0`

## 5. CubeMX checklist

Enable:
- LPUART1 -> Asynchronous
- USART3 -> Asynchronous
- SYS -> Serial Wire
- DAC2 -> Channel 1 (optional physical-output stage)

Set:
- LPUART1 = 115200 / 8-N-1
- USART3 = 460800 / 8-N-1

Generate project for:
- STM32CubeIDE
- C
- STM32H7A3ZIT6

## 6. Expected data flow

Arduino:
`OJAS,PROFILE=17,SEQ=25,DEPTH_M=5.0,TEMP_C=22.59,SAL_PSU=36.28,TURB_NTU=0.35,CREF_MPS=1529.86`

STM32 terminal:
`RX -> Mackenzie -> LUT -> W17 -> waveform metadata`

Laptop:
- environment values
- calculated sound speed
- selected Wxx
- waveform metadata
- waveform buffer / plot
