# Source-to-firmware mapping

| Firmware data | Source |
|---|---|
| 24 environmental profiles | `ocean_data(1).csv` representative uniquely matched rows used by the existing Arduino emitter |
| Sensor/Mackenzie selection table | `OJAS_FINAL_SENSOR_MACKENZIE_LUT_24(1).csv` |
| Waveform descriptors | `OJAS_final_waveform_library_24_Barker(1).csv` |

The STM32 tables are compile-time representations of these CSVs; the board does not parse CSV text at runtime.
