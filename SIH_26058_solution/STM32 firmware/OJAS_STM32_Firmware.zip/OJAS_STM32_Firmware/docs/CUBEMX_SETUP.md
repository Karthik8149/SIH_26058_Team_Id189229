# OJAS STM32CubeMX / CubeIDE setup

Target: **NUCLEO-H7A3ZI-Q / STM32H7A3ZIT6**.

## 1. Project
- STM32CubeIDE
- STM32H7A3ZIT6
- HAL driver

## 2. Arduino -> STM32 UART
Configure **LPUART1** at **115200 8-N-1**.

Use the Arduino-side connection:
- Arduino D1/TX -> level shifter -> STM32 **PB7 / LPUART1_RX**
- Common GND

TX from STM32 is not required for the first one-way link.

## 3. STM32 -> Laptop
Configure **USART3** for the ST-LINK Virtual COM Port.

Use at least TX:
- STM32 **PD8 / USART3_TX** -> ST-LINK VCP -> laptop

Recommended baud for waveform transfer: **460800**.
If your ST-LINK/PC setup is unreliable at 460800, start at 115200 and change `OJAS_UART_BAUD_PC`.

## 4. DAC prototype (optional initially)
For physical analog bring-up, configure:
- DAC2 Channel 1 on **PA6**
- timer trigger routed to DAC, e.g. TIM6 TRGO
- DMA enabled for DAC channel

Keep `OJAS_ENABLE_DAC` at `0` until the digital UART path and laptop plot work.

## 5. Clock / timer
The waveform generator uses a **logical 6 MS/s sample rate** for the digital waveform buffer.
The timer/DAC implementation is intentionally disabled by default because actual DAC/DMA throughput must be bench-validated on the selected output path.

## 6. Source files to add
Copy these into CubeMX generated project folders:

`Core/Inc/`: all `ojas_*.h` files.

`Core/Src/`: all `ojas_*.c` files except `main_ojas_integration.c`, whose contents are integrated into your generated `main.c`.

## 7. Cache / DMA
If DAC DMA is enabled later, place the waveform buffer in DMA-accessible SRAM and handle D-cache coherency. The current default keeps DAC disabled so this is not needed for the UART/laptop validation stage.
