# Immediate build order

## Stage A — UART only
- `OJAS_ENABLE_DAC = 0`
- Flash CubeMX project + OJAS modules
- Laptop listens on USART3 VCP
- Arduino sends profile 17
- Expect `OJAS_RESULT ... WAVEFORM=W17 ...`

## Stage B — waveform buffer
- PC monitor receives `OJAS_WAVE_BEGIN`
- 6000 samples for 1 ms at 6 MS/s
- Plot is the exact buffer generated on STM32

## Stage C — additional waveform cases
- Arduino `START_PROFILE=7` -> W07 LFM
- Arduino `START_PROFILE=10` -> W10 Geometric_NFM
- Arduino `START_PROFILE=17` -> W17 Barker-3

## Stage D — DAC
Only after A-C pass. Enable DAC/TIM/DMA and set `OJAS_ENABLE_DAC=1`.
