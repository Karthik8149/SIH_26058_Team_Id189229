# OJAS STM32 Firmware Package

This package implements the STM32 side of the OJAS hardware demo:

```text
Arduino environmental packet
        |
        v
LPUART1 RX
        |
        v
Parse depth / temperature / salinity / turbidity
        |
        v
Mackenzie sound speed (calculated on STM32)
        |
        v
24-row Sensor/Mackenzie LUT
        |
        v
Selected W01-W24
        |
        v
Waveform library descriptor
        |
        v
Generate only selected waveform
        |
        +----> optional DAC + DMA
        |
        v
USART3 / ST-LINK VCP
        |
        v
Laptop plot / diagnostics
```

## Important
The three C tables are generated directly from the supplied OJAS CSV files.
The 24 profile entries match the existing Arduino environmental emitter.
The STM32 does **not** use the Arduino `CREF_MPS` value for waveform selection; it calculates its own Mackenzie sound speed.

## First bring-up order
1. CubeMX UART configuration.
2. Add OJAS source files.
3. Verify `OJAS,STM32,READY`.
4. Connect Arduino TX through a level shifter.
5. Confirm `OJAS_RESULT` on the laptop.
6. Confirm W17 profile first.
7. Confirm W07 and W10.
8. Enable DAC only after UART path is correct.
