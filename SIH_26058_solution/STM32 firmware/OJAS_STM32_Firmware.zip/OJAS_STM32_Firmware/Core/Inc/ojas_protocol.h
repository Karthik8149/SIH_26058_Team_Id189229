#ifndef OJAS_PROTOCOL_H
#define OJAS_PROTOCOL_H

#include <stdint.h>
#include <stdbool.h>
#include "ojas_types.h"

void OJAS_ProtocolInit(void);
bool OJAS_ProtocolFeedByte(uint8_t byte);
bool OJAS_ProtocolTakePacket(OJAS_RxPacket *packet);

#endif
