#ifndef OJAS_PROFILES_H
#define OJAS_PROFILES_H

#include <stdbool.h>
#include "ojas_types.h"

bool OJAS_ProfileGet(uint8_t id, OJAS_Environment *env);

#endif
