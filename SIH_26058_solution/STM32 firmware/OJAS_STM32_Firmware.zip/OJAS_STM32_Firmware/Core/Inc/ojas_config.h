#ifndef OJAS_CONFIG_H
#define OJAS_CONFIG_H

#include <stdint.h>

/*
 * OJAS STM32 prototype configuration.
 *
 * Input: Arduino -> LPUART1 RX
 * Output: STM32 -> laptop through ST-LINK VCP on USART3
 */

#define OJAS_UART_BAUD_ARDUINO       115200U
#define OJAS_UART_BAUD_PC            460800U

/* Logical waveform sample rate used for digital generation/streaming. */
#define OJAS_WAVEFORM_FS_HZ          6000000.0f

/* Largest waveform in the supplied library is 2 ms -> 12000 samples. */
#define OJAS_MAX_WAVEFORM_SAMPLES    12000U

#define OJAS_DAC_MAX_CODE            4095U
#define OJAS_DAC_MID_CODE            2048U

/* Keep disabled initially. Enable only after CubeMX DAC+TIM+DMA bench bring-up. */
#define OJAS_ENABLE_DAC              0

#define OJAS_WAVE_TX_CHUNK_SAMPLES   128U
#define OJAS_RX_LINE_MAX             256U
#define OJAS_WAVEFORM_COUNT           24U

/* Arduino packet validation tolerance. */
#define OJAS_MACKENZIE_COMPARE_TOL_MPS 0.01f

#endif
