#ifndef OJAS_STREAM_H
#define OJAS_STREAM_H

#include <stdint.h>
#include "ojas_types.h"

void OJAS_StreamInit(void);
void OJAS_StreamResult(const OJAS_Environment *env,
                       float calculated_c,
                       const char *waveform_id,
                       const OJAS_WaveformDesc *desc,
                       uint32_t sequence);
void OJAS_StreamWaveform(const char *waveform_id,
                         const OJAS_WaveformDesc *desc,
                         const OJAS_WaveformMeta *meta,
                         const uint16_t *buffer);

#endif
