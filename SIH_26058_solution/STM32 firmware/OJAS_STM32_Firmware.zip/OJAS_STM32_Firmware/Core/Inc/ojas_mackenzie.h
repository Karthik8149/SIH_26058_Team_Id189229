#ifndef OJAS_MACKENZIE_H
#define OJAS_MACKENZIE_H

float OJAS_MackenzieSoundSpeed(float temperature_C,
                               float salinity_PSU,
                               float depth_m);

#endif
