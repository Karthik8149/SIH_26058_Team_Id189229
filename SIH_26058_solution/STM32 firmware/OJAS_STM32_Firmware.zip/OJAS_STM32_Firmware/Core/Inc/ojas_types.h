#ifndef OJAS_TYPES_H
#define OJAS_TYPES_H

#include <stdint.h>
#include <stdbool.h>

#define OJAS_PROFILE_COUNT 24U
#define OJAS_LUT_COUNT     24U
#define OJAS_ID_LEN        4U

typedef struct
{
    uint8_t id;
    float depth_m;
    float temperature_C;
    float salinity_PSU;
    float turbidity_NTU;
    float c_ref_mps;
} OJAS_Environment;

typedef enum
{
    OJAS_WAVE_LFM = 0,
    OJAS_WAVE_GEOMETRIC_NFM,
    OJAS_WAVE_PHASE_CODED
} OJAS_WaveformType;

typedef struct
{
    char id[OJAS_ID_LEN + 1U];
    OJAS_WaveformType type;
    float fc_Hz;
    float B_Hz;
    float Tp_s;
    float f_low_Hz;
    float f_high_Hz;
    uint8_t phase_len;
    int8_t bpsk[8];
    float phase_rad[8];
} OJAS_WaveformDesc;

typedef struct
{
    char waveform_id[OJAS_ID_LEN + 1U];
    float mackenzie_min_mps;
    float mackenzie_max_mps;
    float mackenzie_ref_mps;
    float depth_min_m;
    float depth_max_m;
    float temperature_min_C;
    float temperature_max_C;
    float salinity_min_PSU;
    float salinity_max_PSU;
    float turbidity_min_NTU;
    float turbidity_max_NTU;
} OJAS_SensorLutRow;

typedef struct
{
    uint32_t sequence;
    uint8_t profile;
    float depth_m;
    float temperature_C;
    float salinity_PSU;
    float turbidity_NTU;
    float c_ref_mps;
} OJAS_RxPacket;

typedef struct
{
    uint32_t sample_count;
    float sample_rate_hz;
    float first_freq_hz;
    float last_freq_hz;
} OJAS_WaveformMeta;

#endif
