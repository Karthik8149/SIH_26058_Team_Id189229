#ifndef OJAS_TX_H
#define OJAS_TX_H

#include <stdint.h>
#include <stdbool.h>

bool OJAS_DacStart(uint16_t *buffer, uint32_t sample_count);
void OJAS_DacStop(void);

#endif
