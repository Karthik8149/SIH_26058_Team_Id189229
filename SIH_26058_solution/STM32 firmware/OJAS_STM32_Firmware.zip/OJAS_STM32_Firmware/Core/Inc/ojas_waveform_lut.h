#ifndef OJAS_WAVEFORM_LUT_H
#define OJAS_WAVEFORM_LUT_H

#include "ojas_types.h"

const OJAS_WaveformDesc *OJAS_WaveformFind(const char *waveform_id);
const char *OJAS_WaveformTypeName(OJAS_WaveformType type);

#endif
