#ifndef OJAS_SELECTOR_H
#define OJAS_SELECTOR_H

#include <stdint.h>
#include <stdbool.h>
#include "ojas_types.h"

uint8_t OJAS_SelectWaveform(const OJAS_Environment *env,
                            float sound_speed_mps,
                            char selected_id[5],
                            uint8_t *match_count);

#endif
