#ifndef OJAS_WAVEFORM_GEN_H
#define OJAS_WAVEFORM_GEN_H

#include <stdint.h>
#include <stdbool.h>
#include "ojas_types.h"

bool OJAS_GenerateWaveform(const OJAS_WaveformDesc *desc,
                           uint16_t *buffer,
                           uint32_t capacity,
                           OJAS_WaveformMeta *meta);

#endif
