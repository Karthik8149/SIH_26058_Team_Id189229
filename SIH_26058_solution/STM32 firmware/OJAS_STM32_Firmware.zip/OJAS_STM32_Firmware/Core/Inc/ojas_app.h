#ifndef OJAS_APP_H
#define OJAS_APP_H

#include "main.h"

void OJAS_AppInit(void);
void OJAS_AppProcess(void);
void OJAS_AppUartRxComplete(UART_HandleTypeDef *huart);

#endif
