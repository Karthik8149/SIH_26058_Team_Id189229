#ifndef OJAS_SENSOR_LUT_H
#define OJAS_SENSOR_LUT_H

#include "ojas_types.h"

extern const OJAS_SensorLutRow OJAS_SensorLut[OJAS_LUT_COUNT];

#endif
