#include "ojas_mackenzie.h"

/*
 * Mackenzie et al. sound-speed polynomial used by the OJAS dataset.
 * Inputs:
 *   T = temperature in deg C
 *   S = salinity in PSU
 *   z = depth in m
 * Output: m/s
 */
float OJAS_MackenzieSoundSpeed(float T, float S, float z)
{
    const float Sm35 = S - 35.0f;

    return 1448.96f
         + 4.591f * T
         - 0.05304f * T * T
         + 0.0002374f * T * T * T
         + 1.34f * Sm35
         + 0.0163f * z
         + 1.675e-7f * z * z
         - 0.01025f * T * Sm35
         - 7.139e-13f * T * z * z * z;
}
