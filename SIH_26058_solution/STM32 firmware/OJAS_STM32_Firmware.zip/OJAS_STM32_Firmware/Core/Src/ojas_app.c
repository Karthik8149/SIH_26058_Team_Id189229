#include "ojas_app.h"
#include "ojas_protocol.h"
#include "ojas_mackenzie.h"
#include "ojas_selector.h"
#include "ojas_waveform_lut.h"
#include "ojas_waveform_gen.h"
#include "ojas_stream.h"
#include "ojas_tx.h"
#include "ojas_config.h"
#include "main.h"
#include <string.h>
#include <math.h>
#include <stdio.h>

extern UART_HandleTypeDef huart3;

extern UART_HandleTypeDef hlpuart1;

static uint8_t rx_byte;
static uint16_t waveform_buffer[OJAS_MAX_WAVEFORM_SAMPLES] __attribute__((aligned(32)));
static bool rx_started = false;

void OJAS_AppInit(void)
{
    OJAS_ProtocolInit();
    OJAS_StreamInit();

    if (HAL_UART_Receive_IT(&hlpuart1, &rx_byte, 1U) == HAL_OK)
        rx_started = true;
}

/*
 * Called from HAL_UART_RxCpltCallback().
 * The callback only moves bytes into the OJAS protocol parser;
 * no heavy processing occurs inside the ISR.
 */
void OJAS_AppUartRxComplete(UART_HandleTypeDef *huart)
{
    if (huart == &hlpuart1)
    {
        OJAS_ProtocolFeedByte(rx_byte);
        HAL_UART_Receive_IT(&hlpuart1, &rx_byte, 1U);
    }
}

void OJAS_AppProcess(void)
{
    OJAS_RxPacket rx;

    if (!OJAS_ProtocolTakePacket(&rx)) return;

    OJAS_Environment env;
    env.id = rx.profile;
    env.depth_m = rx.depth_m;
    env.temperature_C = rx.temperature_C;
    env.salinity_PSU = rx.salinity_PSU;
    env.turbidity_NTU = rx.turbidity_NTU;
    env.c_ref_mps = rx.c_ref_mps;

    /* Calculate Mackenzie locally on STM32. */
    float c = OJAS_MackenzieSoundSpeed(env.temperature_C,
                                       env.salinity_PSU,
                                       env.depth_m);

    char selected_id[5] = {0};
    uint8_t match_count = 0U;

    bool matched =
        (OJAS_SelectWaveform(&env, c, selected_id, &match_count) != 0U);

    if (!matched)
    {
        char line[140];
        int n = snprintf(line, sizeof(line),
                         "OJAS_ERROR,SEQ=%lu,PROFILE=%u,MATCH_COUNT=%u,C_MPS=%.5f\r\n",
                         (unsigned long)rx.sequence,
                         (unsigned)rx.profile,
                         (unsigned)match_count,
                         c);
        if (n > 0)
            HAL_UART_Transmit(&huart3, (uint8_t*)line, (uint16_t)n, HAL_MAX_DELAY);
        return;
    }

    const OJAS_WaveformDesc *d = OJAS_WaveformFind(selected_id);

    if (!d)
    {
        HAL_UART_Transmit(&huart3,
                          (uint8_t*)"OJAS_ERROR,WAVEFORM_NOT_FOUND\r\n",
                          32U,
                          HAL_MAX_DELAY);
        return;
    }

    OJAS_WaveformMeta meta;

    /* Generate only the selected Wxx, matching the MATLAB design philosophy. */
    if (!OJAS_GenerateWaveform(d,
                               waveform_buffer,
                               OJAS_MAX_WAVEFORM_SAMPLES,
                               &meta))
    {
        HAL_UART_Transmit(&huart3,
                          (uint8_t*)"OJAS_ERROR,WAVEFORM_GENERATION_FAILED\r\n",
                          40U,
                          HAL_MAX_DELAY);
        return;
    }

    OJAS_StreamResult(&env, c, selected_id, d, rx.sequence);

    /* Optional physical DAC output. */
    OJAS_DacStop();
    (void)OJAS_DacStart(waveform_buffer, meta.sample_count);

    /* Laptop receives the exact generated DAC-code buffer. */
    OJAS_StreamWaveform(selected_id, d, &meta, waveform_buffer);
}
