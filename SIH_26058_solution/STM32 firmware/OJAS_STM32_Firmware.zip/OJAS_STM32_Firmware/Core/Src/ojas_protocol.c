#include "ojas_protocol.h"
#include "ojas_config.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>

static char line_buf[OJAS_RX_LINE_MAX];
static volatile uint16_t line_len = 0U;
static volatile bool line_ready = false;
static OJAS_RxPacket parsed_packet;
static volatile bool packet_ready = false;

static bool parse_float_field(const char *line, const char *key, float *out)
{
    const char *p = strstr(line, key);
    if (!p || !out) return false;
    p += strlen(key);
    char *end = 0;
    float v = strtof(p, &end);
    if (end == p) return false;
    *out = v;
    return true;
}

static bool parse_uint_field(const char *line, const char *key, uint32_t *out)
{
    const char *p = strstr(line, key);
    if (!p || !out) return false;
    p += strlen(key);
    char *end = 0;
    unsigned long v = strtoul(p, &end, 10);
    if (end == p) return false;
    *out = (uint32_t)v;
    return true;
}

static bool parse_profile_packet(const char *line, OJAS_RxPacket *pkt)
{
    if (!strstr(line, "OJAS,")) return false;
    if (!strstr(line, "DEPTH_M=")) return false;
    if (!strstr(line, "TEMP_C=")) return false;
    if (!strstr(line, "SAL_PSU=")) return false;
    if (!strstr(line, "TURB_NTU=")) return false;

    uint32_t tmp = 0U;
    if (!parse_uint_field(line, "PROFILE=", &tmp)) return false;
    pkt->profile = (uint8_t)tmp;

    if (!parse_uint_field(line, "SEQ=", &pkt->sequence)) return false;
    if (!parse_float_field(line, "DEPTH_M=", &pkt->depth_m)) return false;
    if (!parse_float_field(line, "TEMP_C=", &pkt->temperature_C)) return false;
    if (!parse_float_field(line, "SAL_PSU=", &pkt->salinity_PSU)) return false;
    if (!parse_float_field(line, "TURB_NTU=", &pkt->turbidity_NTU)) return false;

    if (!parse_float_field(line, "CREF_MPS=", &pkt->c_ref_mps))
        pkt->c_ref_mps = 0.0f;

    if (pkt->profile < 1U || pkt->profile > OJAS_PROFILE_COUNT) return false;
    if (pkt->depth_m < 0.0f || pkt->temperature_C < -10.0f || pkt->temperature_C > 40.0f) return false;
    if (pkt->salinity_PSU < 0.0f || pkt->salinity_PSU > 50.0f) return false;
    if (pkt->turbidity_NTU < 0.0f) return false;

    return true;
}

static void process_complete_line(void)
{
    OJAS_RxPacket pkt;

    if (parse_profile_packet(line_buf, &pkt))
    {
        parsed_packet = pkt;
        packet_ready = true;
    }
}

void OJAS_ProtocolInit(void)
{
    line_len = 0U;
    line_ready = false;
    packet_ready = false;
}

bool OJAS_ProtocolFeedByte(uint8_t byte)
{
    if (byte == '\n')
    {
        line_buf[line_len] = '\0';
        line_ready = true;
        process_complete_line();
        line_len = 0U;
        line_ready = false;
        return true;
    }

    if (byte == '\r') return false;

    if (line_len < (OJAS_RX_LINE_MAX - 1U))
    {
        line_buf[line_len++] = (char)byte;
    }
    else
    {
        line_len = 0U;
    }

    return false;
}

bool OJAS_ProtocolTakePacket(OJAS_RxPacket *packet)
{
    if (!packet || !packet_ready) return false;
    *packet = parsed_packet;
    packet_ready = false;
    return true;
}
