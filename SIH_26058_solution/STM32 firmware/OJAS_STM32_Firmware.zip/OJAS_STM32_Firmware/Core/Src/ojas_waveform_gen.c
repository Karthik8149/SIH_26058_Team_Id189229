#include "ojas_waveform_gen.h"
#include "ojas_config.h"
#include <math.h>
#ifndef M_PI
#define M_PI 3.14159265358979323846f
#endif

static uint16_t quantize_dac(float x)
{
    float y = (x + 1.0f) * 0.5f;
    if (y < 0.0f) y = 0.0f;
    if (y > 1.0f) y = 1.0f;
    float q = y * 4095.0f;
    int32_t code = (int32_t)lroundf(q);
    if (code < 0) code = 0;
    if (code > 4095) code = 4095;
    return (uint16_t)code;
}

static float wrap_phase_cycles(float x)
{
    x = x - floorf(x);
    if (x < 0.0f) x += 1.0f;
    return x;
}

bool OJAS_GenerateWaveform(const OJAS_WaveformDesc *d,
                           uint16_t *buffer,
                           uint32_t capacity,
                           OJAS_WaveformMeta *meta)
{
    if (!d || !buffer || !meta) return false;
    if (d->Tp_s <= 0.0f || capacity == 0U) return false;

    uint32_t N = (uint32_t)lroundf(d->Tp_s * OJAS_WAVEFORM_FS_HZ);
    if (N == 0U || N > capacity) return false;

    const float dt = 1.0f / OJAS_WAVEFORM_FS_HZ;
    float phase_cycles = 0.0f;
    float f_now = d->f_low_Hz;

    if (d->type == OJAS_WAVE_LFM)
    {
        const float k = (d->f_high_Hz - d->f_low_Hz) / d->Tp_s;

        for (uint32_t n = 0U; n < N; ++n)
        {
            float t = (float)n * dt;
            phase_cycles = d->f_low_Hz * t + 0.5f * k * t * t;
            buffer[n] = quantize_dac(cosf(2.0f * (float)M_PI * phase_cycles));
        }
    }
    else if (d->type == OJAS_WAVE_GEOMETRIC_NFM)
    {
        const float a = logf(d->f_high_Hz / d->f_low_Hz) / d->Tp_s;

        for (uint32_t n = 0U; n < N; ++n)
        {
            float t = (float)n * dt;
            if (fabsf(a) < 1e-12f)
                phase_cycles = d->f_low_Hz * t;
            else
                phase_cycles = (d->f_low_Hz / a) * (expf(a * t) - 1.0f);

            buffer[n] = quantize_dac(cosf(2.0f * (float)M_PI * phase_cycles));
        }
    }
    else if (d->type == OJAS_WAVE_PHASE_CODED)
    {
        if (d->phase_len == 0U || d->phase_len > 8U) return false;
        const float chip_T = d->Tp_s / (float)d->phase_len;

        for (uint32_t n = 0U; n < N; ++n)
        {
            float t = (float)n * dt;
            uint32_t chip = (uint32_t)floorf(t / chip_T);
            if (chip >= d->phase_len) chip = d->phase_len - 1U;
            float phase_offset = d->phase_rad[chip];
            phase_cycles = d->fc_Hz * t + phase_offset / (2.0f * (float)M_PI);
            buffer[n] = quantize_dac(cosf(2.0f * (float)M_PI * phase_cycles));
        }
    }
    else
    {
        return false;
    }

    (void)f_now;
    meta->sample_count = N;
    meta->sample_rate_hz = OJAS_WAVEFORM_FS_HZ;
    meta->first_freq_hz = d->type == OJAS_WAVE_PHASE_CODED ? d->fc_Hz : d->f_low_Hz;
    meta->last_freq_hz = d->type == OJAS_WAVE_PHASE_CODED ? d->fc_Hz : d->f_high_Hz;
    return true;
}
