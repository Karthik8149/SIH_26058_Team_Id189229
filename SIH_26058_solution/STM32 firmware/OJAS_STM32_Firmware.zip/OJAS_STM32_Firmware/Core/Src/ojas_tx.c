#include "ojas_tx.h"
#include "ojas_config.h"
#include "main.h"

extern DAC_HandleTypeDef hdac2;
extern TIM_HandleTypeDef htim6;

bool OJAS_DacStart(uint16_t *buffer, uint32_t sample_count)
{
#if OJAS_ENABLE_DAC
    if (!buffer || sample_count == 0U) return false;

    if (HAL_DAC_Start_DMA(&hdac2,
                          DAC_CHANNEL_1,
                          (uint32_t*)buffer,
                          sample_count,
                          DAC_ALIGN_12B_R) != HAL_OK)
        return false;

    if (HAL_TIM_Base_Start(&htim6) != HAL_OK)
    {
        HAL_DAC_Stop_DMA(&hdac2, DAC_CHANNEL_1);
        return false;
    }

    return true;
#else
    (void)buffer;
    (void)sample_count;
    return true;
#endif
}

void OJAS_DacStop(void)
{
#if OJAS_ENABLE_DAC
    HAL_TIM_Base_Stop(&htim6);
    HAL_DAC_Stop_DMA(&hdac2, DAC_CHANNEL_1);
#endif
}
