/*
 * Copy the OJAS integration portions into your CubeMX-generated main.c.
 * Do NOT replace the generated clock/peripheral init code blindly.
 */

#include "main.h"
#include "ojas_app.h"

/* Existing CubeMX-generated prototypes remain unchanged. */

/*
 * In main(), after MX_*_Init() calls:
 *
 *     OJAS_AppInit();
 *
 * Then inside the while(1) loop:
 *
 *     OJAS_AppProcess();
 *
 * Add this callback to main.c (or another user source file):
 */

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    OJAS_AppUartRxComplete(huart);
}
