#include "ojas_selector.h"
#include "ojas_sensor_lut.h"
#include <string.h>

static bool within(float x, float lo, float hi)
{
    return (x >= lo) && (x <= hi);
}

uint8_t OJAS_SelectWaveform(const OJAS_Environment *env,
                            float sound_speed_mps,
                            char selected_id[5],
                            uint8_t *match_count)
{
    uint8_t matches = 0U;
    const char *first = 0;

    if (selected_id) selected_id[0] = '\0';
    if (match_count) *match_count = 0U;
    if (env == 0) return 0U;

    for (uint32_t i = 0U; i < OJAS_LUT_COUNT; ++i)
    {
        const OJAS_SensorLutRow *r = &OJAS_SensorLut[i];

        bool ok =
            within(sound_speed_mps, r->mackenzie_min_mps, r->mackenzie_max_mps) &&
            within(env->depth_m, r->depth_min_m, r->depth_max_m) &&
            within(env->temperature_C, r->temperature_min_C, r->temperature_max_C) &&
            within(env->salinity_PSU, r->salinity_min_PSU, r->salinity_max_PSU) &&
            within(env->turbidity_NTU, r->turbidity_min_NTU, r->turbidity_max_NTU);

        if (ok)
        {
            ++matches;
            if (first == 0) first = r->waveform_id;
        }
    }

    if (match_count) *match_count = matches;

    if (matches == 1U && first && selected_id)
    {
        strcpy(selected_id, first);
        return 1U;
    }

    return 0U;
}
