#include "ojas_stream.h"
#include "ojas_config.h"
#include "main.h"
#include <stdio.h>
#include <string.h>
#include <math.h>

extern UART_HandleTypeDef huart3;

static void tx_text(const char *s)
{
    HAL_UART_Transmit(&huart3, (uint8_t*)s, (uint16_t)strlen(s), HAL_MAX_DELAY);
}

void OJAS_StreamInit(void)
{
    tx_text("OJAS,STM32,READY\r\n");
}

void OJAS_StreamResult(const OJAS_Environment *env,
                       float calculated_c,
                       const char *waveform_id,
                       const OJAS_WaveformDesc *d,
                       uint32_t sequence)
{
    char line[320];
    float ref_err = 0.0f;
    if (env) ref_err = calculated_c - env->c_ref_mps;

    if (!env || !waveform_id || !d) return;

    int n = snprintf(line, sizeof(line),
        "OJAS_RESULT,SEQ=%lu,PROFILE=%u,DEPTH_M=%.4f,TEMP_C=%.5f,SAL_PSU=%.5f,TURB_NTU=%.5f,C_MPS=%.5f,CREF_MPS=%.5f,CERR_MPS=%.6f,WAVEFORM=%s,TYPE=%s,FC_HZ=%.2f,B_HZ=%.2f,TP_US=%.2f,FLOW_HZ=%.2f,FHIGH_HZ=%.2f\r\n",
        (unsigned long)sequence,
        (unsigned)env->id,
        env->depth_m,
        env->temperature_C,
        env->salinity_PSU,
        env->turbidity_NTU,
        calculated_c,
        env->c_ref_mps,
        ref_err,
        waveform_id,
        OJAS_WaveformTypeName(d->type),
        d->fc_Hz,
        d->B_Hz,
        d->Tp_s * 1e6f,
        d->f_low_Hz,
        d->f_high_Hz);

    if (n > 0) HAL_UART_Transmit(&huart3, (uint8_t*)line, (uint16_t)n, HAL_MAX_DELAY);
}

void OJAS_StreamWaveform(const char *waveform_id,
                         const OJAS_WaveformDesc *d,
                         const OJAS_WaveformMeta *meta,
                         const uint16_t *buffer)
{
    char line[180];
    if (!waveform_id || !d || !meta || !buffer) return;

    int n = snprintf(line, sizeof(line),
        "OJAS_WAVE_BEGIN,ID=%s,TYPE=%s,FC_HZ=%.2f,FS_HZ=%.2f,N=%lu,B_HZ=%.2f,TP_US=%.2f\r\n",
        waveform_id,
        OJAS_WaveformTypeName(d->type),
        d->fc_Hz,
        meta->sample_rate_hz,
        (unsigned long)meta->sample_count,
        d->B_Hz,
        d->Tp_s * 1e6f);

    if (n > 0) HAL_UART_Transmit(&huart3, (uint8_t*)line, (uint16_t)n, HAL_MAX_DELAY);

    uint8_t chunk[OJAS_WAVE_TX_CHUNK_SAMPLES * 2U];
    uint32_t sent = 0U;

    while (sent < meta->sample_count)
    {
        uint32_t count = meta->sample_count - sent;
        if (count > OJAS_WAVE_TX_CHUNK_SAMPLES) count = OJAS_WAVE_TX_CHUNK_SAMPLES;

        for (uint32_t i = 0U; i < count; ++i)
        {
            uint16_t v = buffer[sent + i];
            chunk[2U*i] = (uint8_t)(v & 0xFFU);
            chunk[2U*i + 1U] = (uint8_t)(v >> 8U);
        }

        HAL_UART_Transmit(&huart3, chunk, (uint16_t)(2U * count), HAL_MAX_DELAY);
        sent += count;
    }

    HAL_UART_Transmit(&huart3, (uint8_t*)"OJAS_WAVE_END\r\n", 14U, HAL_MAX_DELAY);
}
