import argparse
import struct
import serial
import numpy as np
import matplotlib.pyplot as plt


def read_line(ser):
    line = ser.readline()
    if not line:
        raise RuntimeError("Serial timeout")
    return line.decode("ascii", errors="replace").strip()


def main():
    ap = argparse.ArgumentParser(description="OJAS STM32 VCP monitor")
    ap.add_argument("port", help="COM port, e.g. COM7")
    ap.add_argument("--baud", type=int, default=460800)
    args = ap.parse_args()

    ser = serial.Serial(args.port, args.baud, timeout=5)
    print(f"Opened {args.port} @ {args.baud}")

    fig = None

    while True:
        line = read_line(ser)
        print(line)

        if line.startswith("OJAS_WAVE_BEGIN"):
            fields = {}
            for part in line.split(",")[1:]:
                if "=" in part:
                    k, v = part.split("=", 1)
                    fields[k] = v

            n = int(fields["N"])
            fs = float(fields["FS_HZ"])
            wid = fields["ID"]

            raw = ser.read(n * 2)
            if len(raw) != n * 2:
                raise RuntimeError(f"Expected {n*2} bytes, received {len(raw)}")

            samples = np.frombuffer(raw, dtype="<u2").astype(np.float64)
            x = (samples / 4095.0) * 2.0 - 1.0
            t = np.arange(n) / fs

            # Consume end marker.
            end = read_line(ser)
            if end != "OJAS_WAVE_END":
                print("Warning: unexpected waveform terminator:", end)

            plt.figure(figsize=(11, 7))
            plt.subplot(2, 1, 1)
            max_pts = min(n, 12000)
            idx = np.linspace(0, n - 1, max_pts).astype(int)
            plt.plot(t[idx] * 1e6, x[idx])
            plt.grid(True)
            plt.xlabel("Time (us)")
            plt.ylabel("Amplitude")
            plt.title(f"STM32 waveform buffer — {wid}")

            plt.subplot(2, 1, 2)
            if n >= 16:
                win = np.hanning(n)
                X = np.fft.rfft(x * win)
                f = np.fft.rfftfreq(n, 1.0 / fs)
                mag = np.abs(X)
                mag /= np.max(mag) + 1e-15
                plt.plot(f / 1e3, 20 * np.log10(mag + 1e-12))
                plt.xlim(0, min(fs / 2, 600))
                plt.grid(True)
                plt.xlabel("Frequency (kHz)")
                plt.ylabel("Magnitude (dB)")
                plt.title("FFT of actual STM32-transmitted sample buffer")

            plt.tight_layout()
            plt.show(block=False)
            plt.pause(0.001)


if __name__ == "__main__":
    main()
